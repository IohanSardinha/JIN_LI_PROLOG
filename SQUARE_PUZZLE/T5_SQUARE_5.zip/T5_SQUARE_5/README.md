# PLOG - Segundo Projeto

Grupo: Square_5

Turma: 5

Iohan Xavier Sardinha Dutra Soares (up201801011)

João Diogo Vila Franca Gonçalves (up201806162)

---
## Instalação e Execução
Abrir o SICStus Prolog e fazer consult do ficheiro "square.pl".
executar o comando :puzzle([L1],[L2])., em que L1 e uma lista com os valores das linhas e L2 e uma lista com os valores das colunas